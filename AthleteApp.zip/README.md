Open in Android Studio -> Build -> Build APK(s)
APK at app/build/outputs/apk/debug/app-debug.apk
